package oops_concept;

public class Methodoverridinga
{
    int speedlimit = 98;
    void abc() 
    {
		System.out.println("child class");
    }
}
