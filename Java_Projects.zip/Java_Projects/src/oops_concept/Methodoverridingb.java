package oops_concept;

public class Methodoverridingb extends Methodoverridinga {


	int speedlimit = 100;

	void abc() {
		System.out.println("extended class ");
	}

	void cde() {

		System.out.println("speed limit");
		System.out.println(super.speedlimit);
	}

	public static void main(String[] args) {
		Methodoverridinga rr = new Methodoverridingb(); // dynamic method dispatch
		System.out.println(rr.speedlimit);
		rr.abc();
		System.out.println("----dynamic method dispatch------");

		Methodoverridingb re = new Methodoverridingb();
		System.out.println(re.speedlimit);
		// re.abc();
		re.cde();
	}

}



