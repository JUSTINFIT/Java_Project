package oops_concept;

	abstract class RBI
	{
		public void neftTime()
		{
			System.out.println("NEFT TIME is 9:00 AM TO 5:00 PM");
		}
		
		abstract public float roI();
		abstract public void modeOfPayment();
	}

	class SBI extends RBI
	{
	@Override
		public float roI()
		{
			return 9f;
		}	
		
		@Override

	public void modeOfPayment()
	{
		System.out.println("Mode of payment: ");
		System.out.println("IMPS");
		System.out.println("NEFT");
	}
	}
		
	class Axis extends RBI
		{
		@Override
			public float roI()
			{
				return 8;
			}	
			
			@Override
		
		public void modeOfPayment()
		{
			System.out.println("Mode of payment: ");
			System.out.println("IMPS");
			System.out.println("NEFT");
		}
	}


	public class AbstractionClass 
	{
	    public static void main(String[]args)
	    {
	    	System.out.println("\n\n***Welcome To SBI***");
	    	SBI s=new SBI();
	    	System.out.println("ROI of SBI: "+s.roI()+"%");
	    	s.modeOfPayment();
	    	s.neftTime();
	    	
	    	System.out.println("\n\n***Welcome To AXIS***");
	    	Axis a=new Axis();
	    	System.out.println("ROI of Axis: "+s.roI()+"%");
	    	s.modeOfPayment();
	    	s.neftTime();
	    	
	    }
	}


