package oops_concept;

public class Encapsulationb {

		public static void main(String[] args) {
			Encapsulationa en= new Encapsulationa ();
			
			en.setName("Justin");
			System.out.println(en.getName());
		}



	}


