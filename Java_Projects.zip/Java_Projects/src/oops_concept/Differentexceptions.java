package oops_concept;

public class Differentexceptions {


		public static void main(String[] args) {
			try {
				int a[] = new int[5];
				a[3] = 30 / 3;
				System.out.println("try block is executed");
			} catch (ArithmeticException e) {
				System.out.println("task 1 is completed");
			} catch (ArrayIndexOutOfBoundsException e) {
				System.out.println("task 2 is completed");
			} catch (Exception e) {
				System.out.println("common task is completed");
			} finally {
				System.out.println("finally this excuted");
			}
			System.out.println("rest of the code");

		}

	}


