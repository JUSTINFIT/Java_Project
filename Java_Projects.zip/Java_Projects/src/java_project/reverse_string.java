package java_project;

import java.util.Scanner;

public class reverse_string 
{
	String reverse(String s)
	{
	 if(s.length() == 0)
     	 return " ";
  	 return s.charAt(s.length()-1) + reverse(s.substring(0,s.length()-1));
	}
	public static void main(String[ ] arg)
	{
		reverse_string rev=new reverse_string();
	    Scanner s=new Scanner(System.in);
	    System.out.print("Enter a string : ");
	    String  str=s.nextLine();	
	    System.out.println("Reverse of a String  :"+rev.reverse(str));
	}	
	
}
