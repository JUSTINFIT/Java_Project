package java_project;

public class remove_first_and_last_letter 
{
	public static String
    removeFirstandLast(String str)
    {
        str = str.substring(1, str.length() - 1);
        return str;
    }
 
    public static void main(String args[])
    {
        String str = "Edubridge";
        System.out.print(removeFirstandLast(str));
    }
}
