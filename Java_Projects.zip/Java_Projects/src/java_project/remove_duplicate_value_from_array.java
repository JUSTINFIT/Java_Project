package java_project;

import java.util.Arrays;
import java.util.LinkedHashSet;

public class remove_duplicate_value_from_array
{
   public static void main(String[] args)   
   {
	   int[] array = {1, 2, 2, 3, 4, 4, 5, 6, 6, 7};

       LinkedHashSet<Integer> set = new LinkedHashSet<>();
       for (int num : array) {
           set.add(num);
       }

       int[] newArray = new int[set.size()];
       int index = 0;
       for (int num : set) {
           newArray[index++] = num;
       }

       System.out.println("Original array: " + Arrays.toString(array));
       System.out.println("Array after removing duplicates: " + Arrays.toString(newArray));
   }
}
